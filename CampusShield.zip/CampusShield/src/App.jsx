import { useEffect, useState } from "react";
import "./App.css";

const emergencyContacts = [
  { id: 1, name: "Campus Security", role: "Campus Emergency Assistance", phone: "YOUR_COLLEGE_NUMBER", icon: "🛡️" },
  { id: 2, name: "Ambulance", role: "Medical Emergency", phone: "108", icon: "🚑" },
  { id: 3, name: "National Emergency", role: "Emergency Helpline", phone: "112", icon: "🚨" },
  { id: 4, name: "Police", role: "Police Assistance", phone: "100", icon: "👮" }
];

function App() {
  const [viewMode, setViewMode] = useState("student");
  const [showSOS, setShowSOS] = useState(false);
  const [alertSent, setAlertSent] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [showMyReports, setShowMyReports] = useState(false);
  const [showContacts, setShowContacts] = useState(false);

  const [reportData, setReportData] = useState({
    category: "Medical Emergency",
    location: "",
    description: ""
  });

  const [reports, setReports] = useState(() => {
    try {
      const savedReports = localStorage.getItem("campusReports");
      return savedReports ? JSON.parse(savedReports) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("campusReports", JSON.stringify(reports));
  }, [reports]);

  const [location, setLocation] = useState(null);
  const [locationError, setLocationError] = useState("");
  const [loadingLocation, setLoadingLocation] = useState(false);

  function handleSOS() {
    setAlertSent(false);
    setShowSOS(true);
  }

  function handleReportSubmit(e) {
    e.preventDefault();
    const newReport = {
      id: Date.now(),
      ...reportData,
      status: "Pending",
      date: new Date().toLocaleString()
    };
    setReports(previous => [...previous, newReport]);
    setReportData({
      category: "Medical Emergency",
      location: "",
      description: ""
    });
    setShowReport(false);
    alert("Incident report saved successfully!");
  }

  function updateReportStatus(id, newStatus) {
    setReports(previous =>
      previous.map(report =>
        report.id === id ? { ...report, status: newStatus } : report
      )
    );
  }

  function getCurrentLocation() {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by this browser.");
      return;
    }

    setLoadingLocation(true);
    setLocationError("");

    navigator.geolocation.getCurrentPosition(
      position => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy
        });
        setLoadingLocation(false);
      },
      error => {
        setLocationError(error.message);
        setLoadingLocation(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  const pendingCount = reports.filter(report => report.status === "Pending").length;
  const assignedCount = reports.filter(report => report.status === "Assigned").length;
  const resolvedCount = reports.filter(report => report.status === "Resolved").length;

  return (
    <div className="app">
      <header className="header">
        <div className="logo">
          <span>🛡️</span>
          <div>
            <h2>CampusShield</h2>
            <p>Campus Safety System</p>
          </div>
        </div>
        <button
          className="switch-button"
          onClick={() => setViewMode(viewMode === "student" ? "security" : "student")}
        >
          {viewMode === "student" ? "Security View" : "Student View"}
        </button>
      </header>

      <main className="container">
        {viewMode === "student" ? (
          <>
            <section className="welcome">
              <p className="greeting">STUDENT PORTAL</p>
              <h1>Hello, Student 👋</h1>
              <p>Your safety matters. We're here to help.</p>
            </section>

            <section className="safety-card">
              <span className="status-icon">✓</span>
              <div>
                <h3>Campus Safety Status</h3>
                <p>Demo status: All systems operational</p>
              </div>
            </section>

            <section className="sos-section">
              <h2>Emergency Assistance</h2>
              <p>Need immediate assistance?</p>
              <button className="sos-button" onClick={handleSOS}>SOS</button>
              <p className="sos-caption">Tap for emergency assistance</p>
            </section>

            <section className="actions-section">
              <h2>Quick Actions</h2>
              <div className="action-grid">
                <button className="action-card" onClick={() => setShowReport(true)}>
                  <span>📝</span>
                  <h3>Report Incident</h3>
                  <p>Report a campus issue</p>
                </button>
                <button className="action-card" onClick={getCurrentLocation}>
                  <span>📍</span>
                  <h3>Share Location</h3>
                  <p>Get your current location</p>
                </button>
                <button className="action-card" onClick={() => setShowContacts(true)}>
                  <span>📞</span>
                  <h3>Emergency Contacts</h3>
                  <p>Important phone numbers</p>
                </button>
                <button className="action-card" onClick={() => setShowMyReports(true)}>
                  <span>📋</span>
                  <h3>My Reports</h3>
                  <p>{reports.length} reports submitted</p>
                </button>
              </div>
            </section>

            <section className="location-card">
              <h2>📍 Your Current Location</h2>
              {loadingLocation && <p>Getting your location...</p>}
              {location && (
                <div>
                  <p>Latitude: {location.latitude}</p>
                  <p>Longitude: {location.longitude}</p>
                  <p>Accuracy: {Math.round(location.accuracy)} metres</p>
                  <a
                    href={`https://www.google.com/maps?q=${location.latitude},${location.longitude}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    View on Google Maps
                  </a>
                </div>
              )}
              {locationError && <p className="location-error">{locationError}</p>}
            </section>
          </>
        ) : (
          <>
            <section className="welcome">
              <p className="greeting">SECURITY PERSONNEL</p>
              <h1>Security Dashboard 🛡️</h1>
              <p>Monitor and manage campus incidents.</p>
            </section>

            <div className="security-stats">
              <div className="security-stat"><p>Pending</p><h2>{pendingCount}</h2></div>
              <div className="security-stat"><p>Assigned</p><h2>{assignedCount}</h2></div>
              <div className="security-stat"><p>Resolved</p><h2>{resolvedCount}</h2></div>
            </div>

            <section className="security-reports">
              <h2>Reported Incidents</h2>
              {reports.length === 0 ? (
                <div className="empty-reports">
                  <span>📭</span>
                  <h3>No incidents reported</h3>
                  <p>Student reports will appear here.</p>
                </div>
              ) : (
                reports.map(report => (
                  <div className="security-report-card" key={report.id}>
                    <div className="report-top">
                      <span className="report-category">{report.category}</span>
                      <span className="report-status">{report.status}</span>
                    </div>
                    <h3>📍 {report.location}</h3>
                    <p>{report.description}</p>
                    <small>{report.date}</small>
                    <label>Update Incident Status</label>
                    <select
                      value={report.status}
                      onChange={e => updateReportStatus(report.id, e.target.value)}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Assigned">Assigned</option>
                      <option value="Resolved">Resolved</option>
                    </select>
                  </div>
                ))
              )}
            </section>
          </>
        )}
      </main>

      <footer className="footer">
        <p>CampusShield © 2026</p>
        <p>Building a safer campus together.</p>
      </footer>

      {showSOS && (
        <div className="modal-overlay">
          <div className="modal">
            {!alertSent ? (
              <>
                <div className="warning-icon">!</div>
                <h2>Emergency SOS</h2>
                <p>Are you sure you want to activate the emergency demonstration?</p>
                <button className="confirm-button" onClick={() => setAlertSent(true)}>Confirm SOS</button>
                <button className="cancel-button" onClick={() => setShowSOS(false)}>Cancel</button>
              </>
            ) : (
              <>
                <div className="success-icon">✓</div>
                <h2>Demo Alert Activated!</h2>
                <p>Your SOS demonstration was successful. No real emergency notification was sent.</p>
                <button className="confirm-button" onClick={() => setShowSOS(false)}>Done</button>
              </>
            )}
          </div>
        </div>
      )}

      {showReport && (
        <div className="modal-overlay">
          <div className="modal report-modal">
            <h2>Report an Incident</h2>
            <p>Please provide incident details.</p>
            <form onSubmit={handleReportSubmit}>
              <label>Incident Category</label>
              <select
                value={reportData.category}
                onChange={e => setReportData({ ...reportData, category: e.target.value })}
              >
                <option>Medical Emergency</option>
                <option>Security Issue</option>
                <option>Harassment</option>
                <option>Infrastructure Issue</option>
                <option>Other</option>
              </select>

              <label>Incident Location</label>
              <input
                type="text"
                placeholder="Example: Library Block"
                value={reportData.location}
                onChange={e => setReportData({ ...reportData, location: e.target.value })}
                required
              />

              <label>Description</label>
              <textarea
                placeholder="Describe what happened..."
                value={reportData.description}
                onChange={e => setReportData({ ...reportData, description: e.target.value })}
                required
              />

              <button type="submit" className="confirm-button">Submit Report</button>
              <button type="button" className="cancel-button" onClick={() => setShowReport(false)}>Cancel</button>
            </form>
          </div>
        </div>
      )}

      {showContacts && (
        <div className="modal-overlay">
          <div className="modal contacts-modal">
            <h2>📞 Emergency Contacts</h2>
            <p>Contact the appropriate emergency service.</p>
            {emergencyContacts.map(contact => (
              <div className="contact-item" key={contact.id}>
                <div className="contact-info">
                  <span>{contact.icon}</span>
                  <div>
                    <h3>{contact.name}</h3>
                    <p>{contact.role}</p>
                    <strong>{contact.phone}</strong>
                  </div>
                </div>
                {contact.phone !== "YOUR_COLLEGE_NUMBER" && (
                  <a className="call-button" href={`tel:${contact.phone}`}>Call</a>
                )}
              </div>
            ))}
            <button className="cancel-button" onClick={() => setShowContacts(false)}>Close</button>
          </div>
        </div>
      )}

      {showMyReports && (
        <div className="modal-overlay">
          <div className="modal report-modal">
            <h2>📋 My Reports</h2>
            {reports.length === 0 ? (
              <p>You have not submitted any reports.</p>
            ) : (
              reports.map(report => (
                <div className="my-report-item" key={report.id}>
                  <h3>{report.category}</h3>
                  <p>Location: {report.location}</p>
                  <p>{report.description}</p>
                  <p>Status: <strong>{report.status}</strong></p>
                  <small>{report.date}</small>
                </div>
              ))
            )}
            <button className="cancel-button" onClick={() => setShowMyReports(false)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
